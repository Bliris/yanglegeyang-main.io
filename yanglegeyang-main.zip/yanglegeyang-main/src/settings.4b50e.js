"use strict";
window._CCSettings = {
    platform: "web-mobil",
    groupList: ["default"],
    collisionMatrix: [[true]],
    hasResourcesBundle: true,
    hasStartSceneBundle: false,
    remoteBundles: ["resources", "main"],
    subpackages: [],
    launchScene: "db://assets/scene/main.fire",
    orientation: "portrait",
    server: "https://cat-match-static.easygame2021.com/catMatch/sheep_1_2_8/",
    jsList: [],
    bundleVers: {internal: "e6604", resources: "8b75c", main: "0df91"}
};
